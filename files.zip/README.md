# WH Core Logic v1.0 🧭

**초개인화 장소 추천 및 서사 생성 시스템**

5가지 페르소나와 숙련도(Level)에 따른 완전 맞춤형 장소 추천 및 AI 기반 서사 생성 플랫폼

---

## 🚀 Quick Start (5분 안에 실행하기)

### Prerequisites
```bash
# Docker & Docker Compose 설치 확인
docker --version
docker-compose --version
```

### 즉시 실행
```bash
# 1. 저장소 클론
git clone https://github.com/yourcompany/wh-core-logic.git
cd wh-core-logic

# 2. 환경변수 설정
cp .env.example .env
# .env 파일에서 ANTHROPIC_API_KEY 입력

# 3. 실행
docker-compose up -d

# 4. 브라우저에서 접속
# Backend API: http://localhost:8000/docs
# Frontend: http://localhost:3000
```

---

## 📦 시스템 구성

```
wh-core-system/
├── backend/              # FastAPI 추천 엔진
│   ├── role_definitions.py         # 역할 시스템 정의
│   ├── recommendation_engine.py    # 추천 알고리즘
│   ├── level_system.py             # 레벨/XP 시스템
│   ├── requirements.txt
│   └── Dockerfile
├── ai-engine/            # Claude API 서사 생성
│   └── narrative_generator.py
├── database/             # PostgreSQL + PostGIS
│   └── schema.sql
├── frontend/             # React + TypeScript
│   └── components.tsx
└── docs/                 # 문서
    ├── INTEGRATION_GUIDE.md        # 통합 가이드
    └── ROLE_EXPANSION_ANALYSIS.md  # 역할 분석
```

---

## 🎯 핵심 기능

### 1. 5가지 역할 시스템 (Role System)

| 역할 | 한국어 | Emoji | 특징 |
|------|--------|-------|------|
| **Explorer** | 탐험가 | 🧭 | 히든스팟 발견, 넓은 행동반경 |
| **Healer** | 치유자 | 🌿 | 조용한 쉼터, 좁은 동네 중심 |
| **Archivist** | 수집가 | 📸 | 미적 경험, 감각적 장소 |
| **Relation** | 연결자 | 🤝 | 사람과의 연결, 사교적 장소 |
| **Achiever** | 달성자 | 🏆 | 목표 달성, 챌린지 스팟 |

### 2. 지능형 추천 엔진

**알고리즘**: YouTube RecSys 벤치마킹 (Candidate Generation → Ranking)

```python
Score = (Category_Fit × 0.4) + (Distance × 0.25) + 
        (Vibe_Match × 0.2) + (Cost_Fit × 0.1) + 
        Randomness × 0.05
```

**특징**:
- ✅ PostGIS 공간 쿼리 (반경 내 장소 검색)
- ✅ 다차원 스코어링 (카테고리, 거리, 분위기, 비용)
- ✅ 레벨별 동적 반경 조정
- ✅ 날씨/시간대 보정
- ✅ 탐색(Exploration) 변수로 매일 다른 추천

### 3. AI 서사 생성 엔진

**모델**: Claude 3.5 Sonnet

```
입력: 역할 + 레벨 + 장소 + 행동 + 컨텍스트
  ↓
프롬프트 엔지니어링 (역할별 맞춤)
  ↓
출력: 제목 + 본문(3-4문장) + 통찰(1줄)
```

**예시 출력**:
```
제목: 지도 밖의 발견
본문: 남들은 그냥 지나치는 낡은 간판을 당신은 놓치지 않았습니다...
통찰: "진짜 여행은 검색되지 않는 곳에 있습니다."
```

### 4. 레벨 & 게이미피케이션

**XP 공식**:
```
Total XP = Base XP × Consistency × Diversity × Level_Adjustment
```

**레벨 구간**:
- **Lv.1-5**: Beginner (기능 적응)
- **Lv.6-10**: Intermediate (히든 퀘스트 해금)
- **Lv.11-20**: Advanced (크리에이터 모드)
- **Lv.21-50**: Master (레전더리 상태)

**스트릭 보너스**:
- 3일 연속: 1.2배
- 7일 연속: 1.5배
- 30일 연속: 2.0배

---

## 🛠 기술 스택

### Backend
- **Framework**: FastAPI (Python 3.11+)
- **Database**: PostgreSQL 14 + PostGIS 3.2
- **Async**: asyncpg, asyncio
- **AI**: Anthropic Claude API

### Frontend
- **Framework**: React 18 + TypeScript
- **State**: TanStack Query (React Query)
- **Styling**: Tailwind CSS
- **Maps**: Google Maps API / Mapbox

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Caching**: Redis
- **Monitoring**: Sentry, Structlog

---

## 📊 API 예제

### 1. 장소 추천 받기

**Request**:
```bash
curl -X POST http://localhost:8000/api/v1/recommendations \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "user-123",
    "role_type": "explorer",
    "user_level": 8,
    "current_location": {
      "latitude": 37.4979,
      "longitude": 127.0276
    },
    "mood": {
      "mood_text": "호기심 넘치는",
      "intensity": 0.8
    }
  }'
```

**Response**:
```json
{
  "recommendations": [
    {
      "place_id": "place-123",
      "name": "히든 골목 이탈리안",
      "distance_meters": 1234.5,
      "score": 87.5,
      "reason": "탐험가에게 딱 맞는 히든스팟입니다",
      "vibe_tags": ["hidden", "authentic", "romantic"]
    }
  ],
  "radius_used": 5000
}
```

### 2. 서사 생성하기

**Request**:
```bash
curl -X POST http://localhost:8000/api/v1/narratives \
  -H "Content-Type: application/json" \
  -d '{
    "user_role": "explorer",
    "user_level": 8,
    "place_name": "낡은 골목 서점",
    "action_log": "45분 체류, 오래된 책 구경"
  }'
```

**Response**:
```json
{
  "title": "지도 밖의 발견",
  "body": "남들은 그냥 지나치는 낡은 간판을...",
  "insight": "진짜 여행은 검색되지 않는 곳에 있습니다."
}
```

---

## 📚 문서

### 필수 문서
- [**통합 가이드**](docs/INTEGRATION_GUIDE.md) - 설치, 배포, API 전체 가이드
- [**역할 분석**](docs/ROLE_EXPANSION_ANALYSIS.md) - 5가지 역할 심화 분석

### 코드 문서
- `backend/role_definitions.py` - 역할 시스템 전체 정의
- `backend/recommendation_engine.py` - 추천 알고리즘 로직
- `backend/level_system.py` - 레벨/XP/스트릭 계산
- `ai-engine/narrative_generator.py` - AI 서사 생성 엔진

---

## 🎨 역할별 사용 예시

### 탐험가 (Explorer)
```python
# 넓은 반경, 히든스팟 중심
radius = 5000m (Lv.1) → 10000m (Lv.10)
preferred = ["골목길", "이색장소", "히든스팟"]
cost_sensitivity = 0.2  # 비용보다 경험
```

### 치유자 (Healer)
```python
# 좁은 반경, 조용한 장소
radius = 800m (Lv.1) → 2000m (Lv.10)
preferred = ["공원", "북카페", "숲"]
cost_sensitivity = 0.8  # 무료/저렴 선호
```

### 수집가 (Archivist)
```python
# 중간 반경, 감각적 장소
radius = 2000m (Lv.1) → 5000m (Lv.10)
preferred = ["전시관", "뷰맛집", "갤러리"]
cost_sensitivity = 0.5  # 가심비
```

### 연결자 (Relation)
```python
# 중간 반경, 사교적 장소
radius = 2000m (Lv.1) → 5000m (Lv.10)
preferred = ["맛집", "카페", "액티비티"]
cost_sensitivity = 0.6  # N빵 가능
```

### 달성자 (Achiever)
```python
# 넓은 반경, 목적 지향
radius = 5000m (Lv.1) → 15000m (Lv.10)
preferred = ["헬스장", "러닝코스", "챌린지스팟"]
cost_sensitivity = 0.3  # 목적 중심
```

---

## 🧪 테스트

```bash
# Backend 테스트
cd backend
pytest tests/ -v --cov=.

# Integration 테스트
python -m pytest tests/integration/ -v
```

---

## 🚢 배포

### Docker Compose (권장)
```bash
# 프로덕션 배포
docker-compose -f docker-compose.prod.yml up -d

# 로그 확인
docker-compose logs -f backend
```

### Manual 배포
```bash
# Backend
cd backend
uvicorn recommendation_engine:app --host 0.0.0.0 --port 8000 --workers 4

# Frontend
cd frontend
npm run build
npm start
```

---

## 🔧 환경변수

```bash
# Backend (.env)
DATABASE_URL=postgresql://user:pass@localhost:5432/wh_core
ANTHROPIC_API_KEY=sk-ant-xxx
SECRET_KEY=your-secret-key
REDIS_URL=redis://localhost:6379

# Frontend (.env.local)
REACT_APP_API_URL=http://localhost:8000
REACT_APP_MAP_API_KEY=your-map-key
```

---

## 📈 성능 최적화

### Database Indexing
```sql
-- 공간 인덱스 (필수)
CREATE INDEX idx_places_location ON places USING GIST(location);

-- 복합 인덱스
CREATE INDEX idx_places_category_rating 
ON places(primary_category, average_rating DESC);
```

### Caching Strategy
```python
# Redis 캐싱 (추천 결과 5분)
cache_key = f"rec:{user_id}:{role}:{lat}:{lon}"
redis.setex(cache_key, 300, json.dumps(recommendations))
```

### Connection Pooling
```python
# asyncpg 풀 최적화
pool = await asyncpg.create_pool(
    min_size=10,
    max_size=50,
    max_queries=50000
)
```

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

---

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 👥 Team

- **PM**: WH Core Team
- **Backend**: FastAPI + PostgreSQL
- **AI**: Claude 3.5 Sonnet
- **Frontend**: React + TypeScript

---

## 📞 Contact

- **Email**: dev@whcore.com
- **Documentation**: https://docs.whcore.com
- **Support**: https://support.whcore.com

---

## 🎯 Roadmap

### ✅ Phase 1 (Current)
- [x] 역할 시스템 (5가지)
- [x] 추천 엔진 (PostGIS)
- [x] AI 서사 생성
- [x] 레벨/XP 시스템

### 🔄 Phase 2 (Q2 2026)
- [ ] 실시간 알림
- [ ] 소셜 기능 (친구, 공유)
- [ ] 크리에이터 모드
- [ ] 모바일 앱 (React Native)

### 📋 Phase 3 (Q3 2026)
- [ ] 커뮤니티 퀘스트
- [ ] 브랜드 협업
- [ ] 수익화 모델
- [ ] 글로벌 확장

---

**Version**: 1.0.0  
**Last Updated**: 2026-02-09  
**Status**: Production Ready ✅
